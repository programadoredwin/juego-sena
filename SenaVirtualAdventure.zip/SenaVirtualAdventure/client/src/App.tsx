import { Suspense, useEffect, useState } from "react";
import { Canvas } from "@react-three/fiber";
import { KeyboardControls } from "@react-three/drei";
import { useAudio } from "./lib/stores/useAudio";
import Scene from "./components/game/Scene";
import GameUI from "./components/game/GameUI";
import "@fontsource/inter";
import { Loading } from "./components/ui/interface";

// Define control keys for the game
export enum Controls {
  forward = 'forward',
  backward = 'backward',
  left = 'left',
  right = 'right',
  interact = 'interact',
}

// Control key mappings
const keyMap = [
  { name: Controls.forward, keys: ["KeyW", "ArrowUp"] },
  { name: Controls.backward, keys: ["KeyS", "ArrowDown"] },
  { name: Controls.left, keys: ["KeyA", "ArrowLeft"] },
  { name: Controls.right, keys: ["KeyD", "ArrowRight"] },
  { name: Controls.interact, keys: ["KeyE", "Space"] },
];

// Main App component
function App() {
  const [isLoaded, setIsLoaded] = useState(false);
  const { setBackgroundMusic, setHitSound, setSuccessSound } = useAudio();

  // Load audio files when the app starts
  useEffect(() => {
    // Load background music
    const bgMusic = new Audio("/sounds/background.mp3");
    bgMusic.loop = true;
    bgMusic.volume = 0.3;
    setBackgroundMusic(bgMusic);

    // Load sound effects
    const hit = new Audio("/sounds/hit.mp3");
    hit.volume = 0.5;
    setHitSound(hit);

    const success = new Audio("/sounds/success.mp3");
    success.volume = 0.5;
    setSuccessSound(success);

    // Mark loading as complete after a short delay to ensure everything is set up
    const timer = setTimeout(() => setIsLoaded(true), 800);
    
    return () => clearTimeout(timer);
  }, [setBackgroundMusic, setHitSound, setSuccessSound]);

  if (!isLoaded) {
    return <Loading />;
  }

  return (
    <div className="w-full h-full">
      <KeyboardControls map={keyMap}>
        <Canvas
          shadows
          camera={{
            position: [0, 2, 8],
            fov: 50,
            near: 0.1,
            far: 1000
          }}
          gl={{
            antialias: true
          }}
        >
          <color attach="background" args={["#87CEEB"]} />
          <Suspense fallback={null}>
            <Scene />
          </Suspense>
        </Canvas>
        <GameUI />
      </KeyboardControls>
    </div>
  );
}

export default App;
