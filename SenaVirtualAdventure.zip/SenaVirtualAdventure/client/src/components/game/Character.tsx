import { useRef, useEffect, useState } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { useSena } from "@/lib/stores/useSena";
import { useKeyboardControls } from "@react-three/drei";
import { Controls } from "@/App";
import { useAudio } from "@/lib/stores/useAudio";

// Character component - the NPC that interacts with the player
const Character = () => {
  const characterRef = useRef<THREE.Group>(null);
  const { 
    playerPosition, 
    setNearCharacter, 
    isNearCharacter,
    isTalking,
    setIsTalking,
    currentLevel
  } = useSena();
  const interact = useKeyboardControls<Controls>(state => state.interact);
  const [bobOffset, setBobOffset] = useState(0);
  const { playHit } = useAudio();
  
  // Character position based on level
  const characterPosition = {
    x: currentLevel === 1 ? -3 : (currentLevel === 2 ? 3 : 0),
    y: 0,
    z: currentLevel === 3 ? -4 : -4
  };
  
  // Simple idle animation (bobbing up and down)
  useFrame((_, delta) => {
    if (!characterRef.current) return;
    
    // Bobbing animation
    setBobOffset(prev => (prev + delta) % (Math.PI * 2));
    const yOffset = Math.sin(bobOffset * 2) * 0.1;
    characterRef.current.position.y = characterPosition.y + yOffset + 1; // Base height + animation
    
    // Always look at player
    if (playerPosition) {
      const lookAtPos = new THREE.Vector3(
        playerPosition.x,
        characterPosition.y + 1.7, // Look at player's head level
        playerPosition.z
      );
      
      characterRef.current.lookAt(lookAtPos);
    }
    
    // Check if player is near the character
    if (playerPosition) {
      const distance = Math.sqrt(
        Math.pow(playerPosition.x - characterPosition.x, 2) +
        Math.pow(playerPosition.z - characterPosition.z, 2)
      );
      
      const isNear = distance < 2.5; // Within interaction distance
      setNearCharacter(isNear);
    }
  });
  
  // Handle interaction key press
  useEffect(() => {
    let timeout: NodeJS.Timeout;
    
    if (interact && isNearCharacter && !isTalking) {
      console.log("Player interacted with character");
      setIsTalking(true);
      playHit(); // Play interaction sound
      
      // Auto-close after 10 seconds if no further interaction
      timeout = setTimeout(() => {
        if (useSena.getState().isTalking) {
          useSena.getState().setIsTalking(false);
        }
      }, 10000);
    }
    
    return () => {
      if (timeout) clearTimeout(timeout);
    };
  }, [interact, isNearCharacter, isTalking, playHit, setIsTalking]);
  
  return (
    <group 
      ref={characterRef} 
      position={[characterPosition.x, characterPosition.y + 1, characterPosition.z]}
    >
      {/* Character body - Profesora Leidy */}
      <mesh castShadow>
        <capsuleGeometry args={[0.4, 1.2, 4, 16]} />
        <meshStandardMaterial color="#E91E63" /> {/* Color más femenino */}
      </mesh>
      
      {/* Character head */}
      <mesh castShadow position={[0, 1.1, 0]}>
        <sphereGeometry args={[0.35, 32, 32]} />
        <meshStandardMaterial color="#FFCCBC" />
      </mesh>
      
      {/* Hair - representación simple del cabello */}
      <mesh castShadow position={[0, 1.35, 0]}>
        <sphereGeometry args={[0.4, 32, 32]} />
        <meshStandardMaterial color="#4A2700" /> {/* Color marrón oscuro para el cabello */}
      </mesh>
      
      {/* Character eyes */}
      <group position={[0, 1.1, 0.3]}>
        <mesh castShadow position={[-0.1, 0.05, 0]}>
          <sphereGeometry args={[0.05, 16, 16]} />
          <meshStandardMaterial color="#000000" />
        </mesh>
        <mesh castShadow position={[0.1, 0.05, 0]}>
          <sphereGeometry args={[0.05, 16, 16]} />
          <meshStandardMaterial color="#000000" />
        </mesh>
      </group>
      
      {/* Character mouth */}
      <mesh castShadow position={[0, 0.95, 0.3]}>
        <boxGeometry args={[0.2, 0.05, 0.05]} />
        <meshStandardMaterial color="#000000" />
      </mesh>
      
      {/* SENA badge */}
      <mesh castShadow position={[0, 0.5, 0.35]}>
        <planeGeometry args={[0.3, 0.3]} />
        <meshStandardMaterial color="#39b54a" />
      </mesh>
      
      {/* Interaction indicator (only shown when player is near) */}
      {isNearCharacter && (
        <mesh position={[0, 2, 0]}>
          <sphereGeometry args={[0.15, 16, 16]} />
          <meshStandardMaterial 
            color="#FFEB3B" 
            emissive="#FFEB3B"
            emissiveIntensity={0.5}
          />
        </mesh>
      )}
    </group>
  );
};

export default Character;
