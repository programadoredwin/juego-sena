import { useRef, useState, useEffect } from "react";
import * as THREE from "three";
import { useFrame } from "@react-three/fiber";
import { useKeyboardControls } from "@react-three/drei";
import { Controls } from "@/App";
import { useSena } from "@/lib/stores/useSena";

const SPEED = 3;
const ROTATION_SPEED = 2;

const Player = () => {
  const playerRef = useRef<THREE.Group>(null);
  const [playerPosition, setPlayerPosition] = useState(new THREE.Vector3(0, 0, 3));
  const [playerRotation, setPlayerRotation] = useState(0);
  const { setPlayerPosition: updateGlobalPosition } = useSena();
  
  // Get keyboard controls
  const forward = useKeyboardControls<Controls>(state => state.forward);
  const backward = useKeyboardControls<Controls>(state => state.backward);
  const left = useKeyboardControls<Controls>(state => state.left);
  const right = useKeyboardControls<Controls>(state => state.right);
  
  // Movement logic in game loop
  useFrame((_, delta) => {
    if (!playerRef.current) return;
    
    let moved = false;
    const tempPosition = playerPosition.clone();
    let tempRotation = playerRotation;
    
    // Determine movement direction
    if (forward) {
      tempPosition.z -= SPEED * delta * Math.cos(playerRotation);
      tempPosition.x += SPEED * delta * Math.sin(playerRotation);
      moved = true;
    }
    
    if (backward) {
      tempPosition.z += SPEED * delta * Math.cos(playerRotation);
      tempPosition.x -= SPEED * delta * Math.sin(playerRotation);
      moved = true;
    }
    
    if (left) {
      tempRotation += ROTATION_SPEED * delta;
      moved = true;
    }
    
    if (right) {
      tempRotation -= ROTATION_SPEED * delta;
      moved = true;
    }
    
    // Apply boundaries to keep player inside the room
    tempPosition.x = Math.max(-6, Math.min(6, tempPosition.x));
    tempPosition.z = Math.max(-6, Math.min(6, tempPosition.z));
    
    // Apply movement
    if (moved) {
      setPlayerPosition(tempPosition);
      setPlayerRotation(tempRotation);
      
      // Update player ref position and rotation
      playerRef.current.position.copy(tempPosition);
      playerRef.current.rotation.y = tempRotation;
      
      // Update global position for other components
      updateGlobalPosition(tempPosition);
    }
  });
  
  // Log controls for debugging
  useEffect(() => {
    console.log("Player controls:", { forward, backward, left, right });
  }, [forward, backward, left, right]);
  
  return (
    <group ref={playerRef} position={[playerPosition.x, playerPosition.y, playerPosition.z]} rotation={[0, playerRotation, 0]}>
      {/* Edwin - Player representation */}
      <mesh castShadow position={[0, 0.75, 0]}>
        <capsuleGeometry args={[0.3, 1, 4, 16]} />
        <meshStandardMaterial color="#2196F3" /> {/* Color azul para Edwin */}
      </mesh>
      
      {/* Player head */}
      <mesh castShadow position={[0, 1.5, 0]}>
        <sphereGeometry args={[0.25, 32, 32]} />
        <meshStandardMaterial color="#FFD54F" />
      </mesh>
      
      {/* Simple cabello para Edwin */}
      <mesh castShadow position={[0, 1.65, 0]}>
        <boxGeometry args={[0.35, 0.1, 0.35]} />
        <meshStandardMaterial color="#3E2723" />
      </mesh>
      
      {/* SENA insignia en el estudiante */}
      <mesh castShadow position={[0, 0.9, 0.25]} rotation={[0, 0, 0]}>
        <planeGeometry args={[0.2, 0.2]} />
        <meshStandardMaterial color="#FFFFFF" />
      </mesh>
      <mesh castShadow position={[0, 0.9, 0.26]} rotation={[0, 0, 0]}>
        <planeGeometry args={[0.15, 0.15]} />
        <meshStandardMaterial color="#39b54a" />
      </mesh>
    </group>
  );
};

export default Player;
