import { useState, useEffect } from "react";
import { useSena } from "@/lib/stores/useSena";
import { useDialogue } from "@/hooks/useDialogue";
import { useAudio } from "@/lib/stores/useAudio";
import { useKeyboardControls } from "@react-three/drei";
import { Controls } from "@/App";

// DialogueSystem component - Handles character dialogue
const DialogueSystem = () => {
  const { 
    currentLevel, 
    setIsTalking, 
    setShowQuestion,
    characterName
  } = useSena();
  
  const { dialogues, currentDialogueIndex, nextDialogue, hasMoreDialogues } = useDialogue(currentLevel);
  const [displayedText, setDisplayedText] = useState("");
  const [isTyping, setIsTyping] = useState(true);
  const interact = useKeyboardControls<Controls>(state => state.interact);
  const { playHit } = useAudio();
  
  // Text typing effect
  useEffect(() => {
    if (!dialogues[currentDialogueIndex]) return;
    
    const text = dialogues[currentDialogueIndex].text;
    let index = 0;
    setIsTyping(true);
    
    const typingInterval = setInterval(() => {
      setDisplayedText(text.substring(0, index));
      index++;
      
      if (index > text.length) {
        clearInterval(typingInterval);
        setIsTyping(false);
      }
    }, 30); // Speed of typing
    
    return () => clearInterval(typingInterval);
  }, [dialogues, currentDialogueIndex]);
  
  // Handle interaction key press
  useEffect(() => {
    let interactTimeout: NodeJS.Timeout;
    
    const handleInteraction = () => {
      // If still typing, show full text immediately
      if (isTyping) {
        setDisplayedText(dialogues[currentDialogueIndex].text);
        setIsTyping(false);
        return;
      }
      
      playHit();
      
      // If there are more dialogues, go to next one
      if (hasMoreDialogues) {
        nextDialogue();
      } else {
        // End dialogue and show question
        setIsTalking(false);
        setShowQuestion(true);
      }
    };
    
    if (interact) {
      // Debounce to prevent multiple rapid interactions
      interactTimeout = setTimeout(handleInteraction, 200);
    }
    
    return () => {
      if (interactTimeout) clearTimeout(interactTimeout);
    };
  }, [
    interact, 
    isTyping, 
    dialogues, 
    currentDialogueIndex, 
    hasMoreDialogues, 
    nextDialogue, 
    setIsTalking, 
    setShowQuestion,
    playHit
  ]);
  
  if (!dialogues[currentDialogueIndex]) {
    return null;
  }
  
  return (
    <div className="absolute bottom-32 left-0 right-0 mx-auto w-full max-w-3xl px-4 pointer-events-auto">
      <div className="bg-black/80 rounded-lg p-4 text-white">
        <div className="font-bold text-green-400 mb-2">{characterName}</div>
        <div className="text-lg mb-3">{displayedText}</div>
        
        {!isTyping && (
          <div className="text-sm text-green-300 mt-2 animate-pulse">
            {hasMoreDialogues ? "Presiona E para continuar" : "Presiona E para responder"}
          </div>
        )}
      </div>
    </div>
  );
};

export default DialogueSystem;
