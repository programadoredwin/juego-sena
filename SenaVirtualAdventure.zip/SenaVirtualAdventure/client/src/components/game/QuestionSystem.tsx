import { useState, useEffect } from "react";
import { useSena } from "@/lib/stores/useSena";
import { useAudio } from "@/lib/stores/useAudio";

// QuestionSystem component - Handles questions and answers
const QuestionSystem = () => {
  const { 
    currentLevel, 
    setShowQuestion, 
    advanceLevel, 
    setGameCompleted,
    currentQuestion,
    characterName
  } = useSena();
  
  const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
  const [showResult, setShowResult] = useState(false);
  const [isCorrect, setIsCorrect] = useState(false);
  const { playSuccess, playHit } = useAudio();
  
  // Reset state when question changes
  useEffect(() => {
    setSelectedAnswer(null);
    setShowResult(false);
  }, [currentQuestion]);
  
  // Handle answer selection
  const handleAnswerSelect = (index: number) => {
    if (showResult) return;
    
    setSelectedAnswer(index);
    setShowResult(true);
    
    const correct = index === currentQuestion.correctAnswer;
    setIsCorrect(correct);
    
    if (correct) {
      playSuccess();
    } else {
      playHit();
    }
    
    // Wait before proceeding
    setTimeout(() => {
      if (correct) {
        if (currentLevel < 3) {
          advanceLevel();
          setShowQuestion(false);
        } else {
          // Game completed if all levels are done
          setGameCompleted(true);
        }
      } else {
        // Just close the question on wrong answer to try again
        setShowQuestion(false);
      }
    }, 2000);
  };
  
  return (
    <div className="absolute inset-0 bg-black/50 flex items-center justify-center pointer-events-auto">
      <div className="bg-white rounded-lg shadow-lg w-full max-w-2xl mx-4 overflow-hidden">
        {/* Question header */}
        <div className="bg-green-600 text-white p-4">
          <h3 className="font-bold text-xl">Pregunta - Nivel {currentLevel}</h3>
          <p className="opacity-80 text-sm">Responde correctamente para avanzar</p>
        </div>
        
        {/* Question content */}
        <div className="p-6">
          <div className="mb-6">
            <p className="font-semibold text-lg text-gray-800 mb-2">{characterName} pregunta:</p>
            <p className="text-gray-700">{currentQuestion.text}</p>
          </div>
          
          {/* Answer options */}
          <div className="space-y-3">
            {currentQuestion.options.map((option, index) => (
              <button
                key={index}
                className={`w-full text-left p-3 rounded-md border transition-colors ${
                  selectedAnswer === index 
                    ? (showResult 
                        ? (isCorrect ? "bg-green-100 border-green-500" : "bg-red-100 border-red-500") 
                        : "bg-blue-100 border-blue-500")
                    : "bg-gray-50 border-gray-300 hover:bg-gray-100"
                } ${currentQuestion.correctAnswer === index && showResult ? "ring-2 ring-green-500" : ""}`}
                onClick={() => handleAnswerSelect(index)}
                disabled={showResult}
              >
                {option}
              </button>
            ))}
          </div>
          
          {/* Result message */}
          {showResult && (
            <div className={`mt-4 p-3 rounded-md ${isCorrect ? "bg-green-100 text-green-800" : "bg-red-100 text-red-800"}`}>
              {isCorrect 
                ? "¡Correcto! Avanzarás al siguiente nivel." 
                : "Incorrecto. Inténtalo de nuevo."}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default QuestionSystem;
