import { useEffect } from "react";
import { useGame } from "@/lib/stores/useGame";
import { useSena } from "@/lib/stores/useSena";
import { useAudio } from "@/lib/stores/useAudio";

// GameManager component - Controls overall game state and progression
const GameManager = () => {
  const { phase } = useGame();
  const { currentLevel, gameCompleted } = useSena();
  const { backgroundMusic, isMuted } = useAudio();
  
  // Start/stop background music based on game state
  useEffect(() => {
    if (!backgroundMusic) return;
    
    if (phase === "playing" && !gameCompleted && !isMuted) {
      backgroundMusic.play().catch(error => {
        console.log("Background music prevented:", error);
      });
    } else {
      backgroundMusic.pause();
    }
    
    return () => {
      backgroundMusic.pause();
    };
  }, [phase, backgroundMusic, gameCompleted, isMuted]);
  
  // Log game state changes for debugging
  useEffect(() => {
    console.log("Game state:", { phase, currentLevel, gameCompleted });
  }, [phase, currentLevel, gameCompleted]);
  
  return null; // This is a controller component with no visual representation
};

export default GameManager;
