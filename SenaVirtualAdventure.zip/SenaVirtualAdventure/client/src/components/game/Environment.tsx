import { useLayoutEffect, useMemo } from "react";
import * as THREE from "three";
import { useTexture } from "@react-three/drei";
import { useSena } from "@/lib/stores/useSena";

// SENA Environment component - represents a classroom/facility
const Environment = () => {
  const { currentLevel } = useSena();
  
  // Load textures
  const floorTexture = useTexture("/textures/asphalt.png");
  const wallTexture = useTexture("/textures/wood.jpg");
  
  // Configure textures
  useLayoutEffect(() => {
    [floorTexture, wallTexture].forEach(texture => {
      texture.wrapS = texture.wrapT = THREE.RepeatWrapping;
      texture.repeat.set(5, 5);
    });
  }, [floorTexture, wallTexture]);
  
  // Environment objects based on level
  const levelObjects = useMemo(() => {
    // Will hold different objects for each level
    switch(currentLevel) {
      case 1:
        return (
          <>
            {/* Computer desks */}
            <group position={[3, 0, -3]}>
              {[0, 1, 2].map((i) => (
                <mesh key={`desk-${i}`} position={[i * 2.2, 0.5, 0]} castShadow receiveShadow>
                  <boxGeometry args={[2, 0.1, 1]} />
                  <meshStandardMaterial color="#8B4513" />
                </mesh>
              ))}
            </group>
            
            {/* Chairs */}
            <group position={[3, 0, -1.5]}>
              {[0, 1, 2].map((i) => (
                <mesh key={`chair-${i}`} position={[i * 2.2, 0.3, 0]} castShadow receiveShadow>
                  <boxGeometry args={[0.6, 0.6, 0.6]} />
                  <meshStandardMaterial color="#444444" />
                </mesh>
              ))}
            </group>
            
            {/* Whiteboard */}
            <mesh position={[0, 2, -6.9]} castShadow receiveShadow>
              <boxGeometry args={[6, 3, 0.1]} />
              <meshStandardMaterial color="white" />
            </mesh>
          </>
        );
      case 2:
        return (
          <>
            {/* Workshop tables */}
            <group position={[-3, 0, -2]}>
              {[0, 1].map((i) => (
                <mesh key={`table-${i}`} position={[0, 0.6, i * 4]} castShadow receiveShadow>
                  <boxGeometry args={[3, 0.2, 1.5]} />
                  <meshStandardMaterial color="#5D4037" />
                </mesh>
              ))}
            </group>
            
            {/* Equipment */}
            <group position={[-3, 0, -2]}>
              {[0, 1].map((i) => (
                <mesh key={`equipment-${i}`} position={[0, 1, i * 4]} castShadow receiveShadow>
                  <boxGeometry args={[1, 0.8, 1]} />
                  <meshStandardMaterial color="#607D8B" />
                </mesh>
              ))}
            </group>
            
            {/* Information boards */}
            <mesh position={[6.9, 2, 0]} rotation={[0, -Math.PI / 2, 0]} castShadow receiveShadow>
              <boxGeometry args={[4, 2, 0.1]} />
              <meshStandardMaterial color="#FFECB3" />
            </mesh>
          </>
        );
      case 3:
        return (
          <>
            {/* Center display or model */}
            <mesh position={[0, 1, -3]} castShadow receiveShadow>
              <cylinderGeometry args={[2, 2, 0.1, 32]} />
              <meshStandardMaterial color="#E0E0E0" />
            </mesh>
            
            <mesh position={[0, 1.2, -3]} castShadow receiveShadow>
              <boxGeometry args={[1, 0.2, 1]} />
              <meshStandardMaterial color="#4CAF50" />
            </mesh>
            
            {/* Display cases */}
            {[-4, 4].map((x, i) => (
              <mesh key={`case-${i}`} position={[x, 1, -2]} castShadow receiveShadow>
                <boxGeometry args={[1.5, 2, 1]} />
                <meshStandardMaterial color="#BBDEFB" opacity={0.7} transparent />
              </mesh>
            ))}
          </>
        );
      default:
        return null;
    }
  }, [currentLevel]);
  
  return (
    <>
      {/* Floor */}
      <mesh 
        rotation={[-Math.PI / 2, 0, 0]} 
        position={[0, 0, 0]} 
        receiveShadow
      >
        <planeGeometry args={[20, 20]} />
        <meshStandardMaterial map={floorTexture} />
      </mesh>
      
      {/* Walls */}
      <group>
        {/* Back wall */}
        <mesh position={[0, 3.5, -7]} receiveShadow>
          <boxGeometry args={[14, 7, 0.2]} />
          <meshStandardMaterial map={wallTexture} color="#F5F5DC" />
        </mesh>
        
        {/* Left wall */}
        <mesh position={[-7, 3.5, 0]} rotation={[0, Math.PI / 2, 0]} receiveShadow>
          <boxGeometry args={[14, 7, 0.2]} />
          <meshStandardMaterial map={wallTexture} color="#F5F5DC" />
        </mesh>
        
        {/* Right wall */}
        <mesh position={[7, 3.5, 0]} rotation={[0, -Math.PI / 2, 0]} receiveShadow>
          <boxGeometry args={[14, 7, 0.2]} />
          <meshStandardMaterial map={wallTexture} color="#F5F5DC" />
        </mesh>
      </group>
      
      {/* SENA Logo on the wall */}
      <mesh position={[0, 4, -6.8]} receiveShadow>
        <planeGeometry args={[4, 2]} />
        <meshStandardMaterial color="#39b54a" />
      </mesh>
      
      {/* Level-specific objects */}
      {levelObjects}
    </>
  );
};

export default Environment;
