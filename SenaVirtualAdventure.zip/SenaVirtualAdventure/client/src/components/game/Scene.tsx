import { useEffect } from "react";
import * as THREE from "three";
import { Sky, Environment } from "@react-three/drei";
import { useThree } from "@react-three/fiber";
import { useGame } from "@/lib/stores/useGame";
import Environment3D from "./Environment";
import Player from "./Player";
import Character from "./Character";
import GameManager from "./GameManager";

const Scene = () => {
  const { camera } = useThree();
  const phase = useGame(state => state.phase);
  
  // Set up scene
  useEffect(() => {
    // Ensure camera is at the correct starting position
    camera.position.set(0, 2.5, 8);
    camera.lookAt(0, 1, 0);
    
    console.log("Game phase:", phase);
    
    // Start game if not already started
    if (phase === "ready") {
      useGame.getState().start();
    }
    
    return () => {
      // Cleanup if needed
    };
  }, [camera, phase]);

  return (
    <>
      {/* Lighting */}
      <ambientLight intensity={0.5} />
      <directionalLight 
        castShadow
        position={[10, 10, 10]} 
        intensity={1.5} 
        shadow-mapSize={[2048, 2048]}
      />
      <directionalLight 
        position={[-10, 10, -10]} 
        intensity={0.5} 
      />
      
      {/* Sky and environment */}
      <Sky sunPosition={[100, 100, 20]} />
      <Environment preset="city" />
      
      {/* Game elements */}
      <Environment3D />
      <Player />
      <Character />
      <GameManager />
    </>
  );
};

export default Scene;
