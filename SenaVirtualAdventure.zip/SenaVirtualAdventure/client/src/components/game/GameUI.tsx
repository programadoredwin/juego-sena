import { useEffect } from "react";
import { useKeyboardControls } from "@react-three/drei";
import { Controls } from "@/App";
import { useSena } from "@/lib/stores/useSena";
import { useAudio } from "@/lib/stores/useAudio";
import DialogueSystem from "./DialogueSystem";
import QuestionSystem from "./QuestionSystem";

// Main Game UI component
const GameUI = () => {
  const { 
    currentLevel, 
    isNearCharacter, 
    isTalking,
    showQuestion,
    gameCompleted
  } = useSena();
  
  const interact = useKeyboardControls<Controls>(state => state.interact);
  const { toggleMute, isMuted } = useAudio();
  
  // Handle mute toggle with M key
  useEffect(() => {
    const handleKeyPress = (e: KeyboardEvent) => {
      if (e.code === 'KeyM') {
        toggleMute();
      }
    };
    
    window.addEventListener('keydown', handleKeyPress);
    return () => window.removeEventListener('keydown', handleKeyPress);
  }, [toggleMute]);
  
  return (
    <div className="fixed inset-0 pointer-events-none">
      {/* HUD - Always visible */}
      <div className="absolute top-0 left-0 right-0 p-4 flex justify-between items-center">
        <div className="bg-black/70 text-white px-4 py-2 rounded-lg">
          <span>Nivel: {currentLevel}</span>
        </div>
        
        <div className="bg-black/70 text-white px-4 py-2 rounded-lg pointer-events-auto cursor-pointer" onClick={toggleMute}>
          {isMuted ? "🔇" : "🔊"}
        </div>
      </div>
      
      {/* Interaction hint - Only when near character */}
      {isNearCharacter && !isTalking && (
        <div className="absolute bottom-20 left-1/2 transform -translate-x-1/2 bg-black/70 text-white px-4 py-2 rounded-lg text-center">
          Presiona <span className="font-bold">E</span> para interactuar
        </div>
      )}
      
      {/* Dialogue System - When talking */}
      {isTalking && !showQuestion && <DialogueSystem />}
      
      {/* Question System - When a question is shown */}
      {showQuestion && <QuestionSystem />}
      
      {/* Game completed screen */}
      {gameCompleted && (
        <div className="absolute inset-0 bg-black/80 flex flex-col items-center justify-center text-white pointer-events-auto">
          <h1 className="text-4xl font-bold mb-6">¡Felicidades!</h1>
          <p className="text-xl mb-8">Has completado todos los niveles y aprendido sobre el SENA.</p>
          <button 
            className="bg-green-600 hover:bg-green-700 text-white font-bold py-2 px-6 rounded-lg"
            onClick={() => window.location.reload()}
          >
            Jugar de nuevo
          </button>
        </div>
      )}
      
      {/* Controls help */}
      <div className="absolute bottom-4 left-4 bg-black/70 text-white p-3 rounded-lg text-sm">
        <div className="font-bold mb-1">Controles:</div>
        <div>WASD / Flechas - Movimiento</div>
        <div>E / Espacio - Interactuar</div>
        <div>M - Silenciar/Activar sonido</div>
      </div>
    </div>
  );
};

export default GameUI;
