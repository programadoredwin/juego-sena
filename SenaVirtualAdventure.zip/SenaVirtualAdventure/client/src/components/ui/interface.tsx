import { useState, useEffect } from "react";
import { Loader } from "lucide-react";

export const Loading = () => {
  const [dots, setDots] = useState(".");
  
  useEffect(() => {
    const interval = setInterval(() => {
      setDots((prev) => {
        if (prev.length >= 3) return ".";
        return prev + ".";
      });
    }, 500);
    
    return () => clearInterval(interval);
  }, []);
  
  return (
    <div className="fixed inset-0 flex flex-col items-center justify-center bg-black text-white">
      <Loader className="h-12 w-12 animate-spin mb-4" />
      <h2 className="text-2xl font-bold mb-2">Cargando el mundo SENA</h2>
      <p className="text-lg">Preparando el entorno interactivo{dots}</p>
    </div>
  );
};
