import { create } from "zustand";
import * as THREE from "three";
import { questions } from "@/data/questions";
import { senaInfo } from "@/data/senaInfo";

// Define SenaStore state interface
interface SenaState {
  // Player state
  playerPosition: THREE.Vector3;
  setPlayerPosition: (position: THREE.Vector3) => void;
  
  // Character interaction
  isNearCharacter: boolean;
  setNearCharacter: (isNear: boolean) => void;
  isTalking: boolean;
  setIsTalking: (isTalking: boolean) => void;
  characterName: string;
  
  // Level progression
  currentLevel: number;
  advanceLevel: () => void;
  resetLevel: () => void;
  
  // Questions system
  showQuestion: boolean;
  setShowQuestion: (show: boolean) => void;
  currentQuestion: typeof questions[0];
  
  // Game completion
  gameCompleted: boolean;
  setGameCompleted: (completed: boolean) => void;
  
  // SENA information
  senaInformation: typeof senaInfo;
}

// Create the store
export const useSena = create<SenaState>((set, get) => ({
  // Player state
  playerPosition: new THREE.Vector3(0, 0, 3),
  setPlayerPosition: (position) => set({ playerPosition: position }),
  
  // Character interaction
  isNearCharacter: false,
  setNearCharacter: (isNear) => set({ isNearCharacter: isNear }),
  isTalking: false,
  setIsTalking: (isTalking) => set({ isTalking }),
  characterName: "Profesora Leidy",
  
  // Level progression
  currentLevel: 1,
  advanceLevel: () => set((state) => ({ 
    currentLevel: state.currentLevel + 1,
    // Get the corresponding question for the new level
    currentQuestion: questions.find(q => q.level === state.currentLevel + 1) || questions[0]
  })),
  resetLevel: () => set({ currentLevel: 1 }),
  
  // Questions system
  showQuestion: false,
  setShowQuestion: (show) => set({ showQuestion: show }),
  currentQuestion: questions[0], // Initialize with the first question
  
  // Game completion
  gameCompleted: false,
  setGameCompleted: (completed) => set({ gameCompleted: completed }),
  
  // SENA information
  senaInformation: senaInfo
}));
