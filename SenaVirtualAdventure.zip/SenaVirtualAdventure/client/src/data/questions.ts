// Define question data types
export interface Question {
  id: number;
  text: string;
  options: string[];
  correctAnswer: number;
  level: number;
  explanation: string;
}

// Questions for each level
export const questions: Question[] = [
  // Level 1 - Basic questions
  {
    id: 1,
    text: "¿En qué año fue fundado el SENA?",
    options: ["1945", "1957", "1962", "1970"],
    correctAnswer: 1, // 1957
    level: 1,
    explanation: "El SENA fue fundado en 1957 con el objetivo de ofrecer formación profesional."
  },
  {
    id: 2,
    text: "¿Qué significan las siglas SENA?",
    options: [
      "Sistema Educativo Nacional Avanzado", 
      "Servicio Educativo Nacional Autónomo", 
      "Servicio Nacional de Aprendizaje", 
      "Sistema Nacional de Asesoría"
    ],
    correctAnswer: 2, // Servicio Nacional de Aprendizaje
    level: 1,
    explanation: "SENA significa Servicio Nacional de Aprendizaje, que es una institución pública colombiana."
  },
  
  // Level 2 - Intermediate questions
  {
    id: 3,
    text: "¿Cuál de los siguientes NO es un tipo de formación que ofrece el SENA?",
    options: [
      "Formación Técnica", 
      "Formación Tecnológica", 
      "Formación Doctoral", 
      "Formación Complementaria"
    ],
    correctAnswer: 2, // Formación Doctoral
    level: 2,
    explanation: "El SENA ofrece formación técnica, tecnológica y complementaria, pero no ofrece formación doctoral."
  },
  {
    id: 4,
    text: "¿Qué es el Fondo Emprender del SENA?",
    options: [
      "Un fondo para becas internacionales", 
      "Un fondo que financia proyectos empresariales", 
      "Un sistema de ahorro para aprendices", 
      "Un programa de intercambio estudiantil"
    ],
    correctAnswer: 1, // Un fondo que financia proyectos empresariales
    level: 2,
    explanation: "El Fondo Emprender es un fondo creado por el Gobierno Nacional para financiar proyectos empresariales."
  },
  
  // Level 3 - Advanced questions
  {
    id: 5,
    text: "¿Cuál es una de las modalidades de formación que ofrece el SENA actualmente?",
    options: [
      "Solo presencial", 
      "Solo virtual", 
      "Presencial y virtual", 
      "Solo semipresencial"
    ],
    correctAnswer: 2, // Presencial y virtual
    level: 3,
    explanation: "El SENA ofrece formación en modalidades presencial y virtual para garantizar el acceso a la educación."
  },
  {
    id: 6,
    text: "¿Cuál de las siguientes áreas tecnológicas está impulsando el SENA en su formación?",
    options: [
      "Solo robótica industrial", 
      "Inteligencia Artificial, IoT y Big Data", 
      "Solo programación básica", 
      "Ninguna de las anteriores"
    ],
    correctAnswer: 1, // Inteligencia Artificial, IoT y Big Data
    level: 3,
    explanation: "El SENA se ha adaptado a las tendencias mundiales ofreciendo formación en tecnologías emergentes como IA, IoT y Big Data."
  }
];
