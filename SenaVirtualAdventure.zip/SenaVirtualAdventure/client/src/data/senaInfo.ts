// Information about SENA that can be shared by the character
export const senaInfo = {
  // General information
  general: {
    fullName: "Servicio Nacional de Aprendizaje",
    foundedYear: 1957,
    mission: "Ofrecer y ejecutar la formación profesional integral, para la incorporación y el desarrollo de las personas en actividades productivas que contribuyan al desarrollo social, económico y tecnológico de Colombia.",
    vision: "El SENA será reconocido por la efectividad de su gestión, sus aportes al empleo, el emprendimiento y la equidad, como entidad que contribuye a la transformación social y económica del país."
  },
  
  // Key statistics
  statistics: {
    centers: "117 centros de formación a nivel nacional",
    programs: "Más de 400 programas de formación",
    students: "Millones de colombianos capacitados anualmente",
    presence: "Presencia en los 33 departamentos de Colombia"
  },
  
  // Formation types
  formationTypes: [
    "Formación Titulada (Técnica y Tecnológica)",
    "Formación Complementaria",
    "Certificación por Competencias Laborales",
    "Formación Virtual"
  ],
  
  // Special programs
  specialPrograms: [
    {
      name: "Fondo Emprender",
      description: "Financia iniciativas empresariales de aprendices y recién graduados"
    },
    {
      name: "SENA Emprende Rural",
      description: "Promueve la generación de ingresos en la población rural"
    },
    {
      name: "Agencia Pública de Empleo",
      description: "Facilita el encuentro entre oferta y demanda laboral"
    },
    {
      name: "WorldSkills",
      description: "Competencias de habilidades técnicas a nivel mundial"
    }
  ],
  
  // Technological areas
  technologyAreas: [
    "Inteligencia Artificial",
    "Internet de las Cosas (IoT)",
    "Big Data",
    "Robótica",
    "Industria 4.0",
    "Desarrollo de Software",
    "Ciberseguridad"
  ]
};
