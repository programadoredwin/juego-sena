// Define level data types
export interface Level {
  id: number;
  name: string;
  description: string;
  environment: "classroom" | "workshop" | "innovation";
}

// Levels in the game
export const levels: Level[] = [
  {
    id: 1,
    name: "Introducción al SENA",
    description: "Aprende los conceptos básicos sobre el SENA, su historia y misión.",
    environment: "classroom"
  },
  {
    id: 2,
    name: "Programas y Servicios",
    description: "Descubre los diferentes programas de formación y servicios que ofrece el SENA.",
    environment: "workshop"
  },
  {
    id: 3,
    name: "SENA y Tecnología",
    description: "Explora cómo el SENA está innovando con nuevas tecnologías y modalidades de aprendizaje.",
    environment: "innovation"
  }
];
