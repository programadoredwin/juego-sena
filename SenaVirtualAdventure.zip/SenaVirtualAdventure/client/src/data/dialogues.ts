// Define dialogue data types
export interface Dialogue {
  id: number;
  text: string;
  character: string;
  level: number;
  order: number;
}

// Dialogues for each level
export const dialogues: Dialogue[] = [
  // Level 1 - Introduction
  {
    id: 1,
    text: "¡Hola Edwin! Bienvenido al Servicio Nacional de Aprendizaje (SENA). Mi nombre es Leidy, y seré tu guía virtual durante este recorrido educativo.",
    character: "Profesora Leidy",
    level: 1,
    order: 1
  },
  {
    id: 2,
    text: "El SENA es una institución pública colombiana que ofrece formación gratuita a millones de colombianos cada año.",
    character: "Profesora Leidy",
    level: 1,
    order: 2
  },
  {
    id: 3,
    text: "Fue fundado en 1957 con el objetivo de ofrecer formación profesional a los trabajadores, jóvenes y adultos de la industria, el comercio, la agricultura, la minería y la ganadería.",
    character: "Profesora Leidy",
    level: 1,
    order: 3
  },
  {
    id: 4,
    text: "Edwin, te encuentras en una de nuestras aulas de formación. Aquí aprendemos tanto teoría como práctica. Ahora, vamos a comprobar tus conocimientos básicos sobre el SENA.",
    character: "Profesora Leidy",
    level: 1,
    order: 4
  },
  
  // Level 2 - More detailed information
  {
    id: 5,
    text: "¡Excelente Edwin! Has avanzado al siguiente nivel. Ahora estamos en uno de nuestros talleres de práctica.",
    character: "Profesora Leidy",
    level: 2,
    order: 1
  },
  {
    id: 6,
    text: "El SENA ofrece más de 400 programas de formación en diversas áreas como tecnología, industria, comercio, agricultura, servicios, salud, y muchas más.",
    character: "Profesora Leidy",
    level: 2,
    order: 2
  },
  {
    id: 7,
    text: "Nuestra institución cuenta con 117 centros de formación distribuidos en los 33 departamentos del país, lo que nos permite llegar a todos los colombianos.",
    character: "Profesora Leidy",
    level: 2,
    order: 3
  },
  {
    id: 8,
    text: "El SENA también ofrece servicios especiales como el Fondo Emprender, que financia proyectos empresariales de aprendices y recién graduados. Ahora, Edwin, veamos si puedes responder otra pregunta.",
    character: "Profesora Leidy",
    level: 2,
    order: 4
  },
  
  // Level 3 - Advanced information
  {
    id: 9,
    text: "¡Impresionante, Edwin! Has llegado al último nivel. Estamos en nuestra sala de innovación tecnológica.",
    character: "Profesora Leidy",
    level: 3,
    order: 1
  },
  {
    id: 10,
    text: "El SENA se ha adaptado a las tendencias mundiales y ahora ofrece formación en tecnologías emergentes como Inteligencia Artificial, Internet de las Cosas, Big Data, y muchas más.",
    character: "Profesora Leidy",
    level: 3,
    order: 2
  },
  {
    id: 11,
    text: "Además de la formación presencial, el SENA ofrece formación virtual a través de la plataforma 'SENA Virtual', permitiendo que personas de todo el país accedan a educación de calidad sin importar su ubicación.",
    character: "Profesora Leidy",
    level: 3,
    order: 3
  },
  {
    id: 12,
    text: "El SENA también trabaja en colaboración con empresas e instituciones internacionales para ofrecer programas de intercambio y aprendizaje global. Edwin, para finalizar, aquí va la última pregunta.",
    character: "Profesora Leidy",
    level: 3,
    order: 4
  }
];
