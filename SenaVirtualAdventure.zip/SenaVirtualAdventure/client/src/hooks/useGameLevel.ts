import { useState, useEffect, useCallback } from "react";
import { levels } from "@/data/levels";
import { questions } from "@/data/questions";
import { useAudio } from "@/lib/stores/useAudio";

// Hook for handling game level progression
export const useGameLevel = () => {
  const [currentLevel, setCurrentLevel] = useState(1);
  const [levelCompleted, setLevelCompleted] = useState<boolean[]>([false, false, false]);
  const [gameCompleted, setGameCompleted] = useState(false);
  const { playSuccess } = useAudio();
  
  // Get current level data
  const currentLevelData = levels.find(l => l.id === currentLevel);
  
  // Get questions for current level
  const currentLevelQuestions = questions.filter(q => q.level === currentLevel);
  
  // Advance to next level
  const advanceLevel = useCallback(() => {
    if (currentLevel < levels.length) {
      // Mark current level as completed
      const newLevelCompleted = [...levelCompleted];
      newLevelCompleted[currentLevel - 1] = true;
      setLevelCompleted(newLevelCompleted);
      
      // Move to next level
      setCurrentLevel(prev => prev + 1);
      playSuccess();
      console.log(`Advanced to level ${currentLevel + 1}`);
      
      return true;
    } else {
      // Game completed
      const newLevelCompleted = [...levelCompleted];
      newLevelCompleted[currentLevel - 1] = true;
      setLevelCompleted(newLevelCompleted);
      setGameCompleted(true);
      playSuccess();
      console.log("Game completed!");
      
      return false;
    }
  }, [currentLevel, levelCompleted, playSuccess]);
  
  // Reset game to first level
  const resetGame = useCallback(() => {
    setCurrentLevel(1);
    setLevelCompleted([false, false, false]);
    setGameCompleted(false);
    console.log("Game reset to level 1");
  }, []);
  
  // Check if all levels are completed
  useEffect(() => {
    const allCompleted = levelCompleted.every(level => level);
    if (allCompleted && currentLevel > levels.length) {
      setGameCompleted(true);
    }
  }, [levelCompleted, currentLevel]);
  
  return {
    currentLevel,
    currentLevelData,
    levelCompleted,
    gameCompleted,
    currentLevelQuestions,
    advanceLevel,
    resetGame,
    setGameCompleted
  };
};
