import { useState, useEffect } from "react";
import { useSena } from "@/lib/stores/useSena";
import { useKeyboardControls } from "@react-three/drei";
import { Controls } from "@/App";

// Hook for handling character interactions
export const useCharacterInteraction = () => {
  const [canInteract, setCanInteract] = useState(false);
  const [interactionDistance, setInteractionDistance] = useState(2.5);
  
  const { 
    playerPosition, 
    isNearCharacter,
    isTalking,
    setIsTalking
  } = useSena();
  
  const interact = useKeyboardControls<Controls>(state => state.interact);
  
  // Check if player is within interaction distance
  useEffect(() => {
    setCanInteract(isNearCharacter && !isTalking);
  }, [isNearCharacter, isTalking]);
  
  // Handle interaction key press
  useEffect(() => {
    if (interact && canInteract) {
      setIsTalking(true);
      console.log("Interaction initiated with character");
    }
  }, [interact, canInteract, setIsTalking]);
  
  // Custom interaction logic
  const initiateInteraction = () => {
    if (canInteract) {
      setIsTalking(true);
      return true;
    }
    return false;
  };
  
  // End the current interaction
  const endInteraction = () => {
    setIsTalking(false);
  };
  
  // Set custom interaction distance
  const setCustomInteractionDistance = (distance: number) => {
    setInteractionDistance(distance);
  };
  
  return { 
    canInteract, 
    initiateInteraction, 
    endInteraction, 
    interactionDistance,
    setCustomInteractionDistance
  };
};
