import { useState, useEffect, useCallback } from "react";
import { dialogues } from "@/data/dialogues";

// Hook for handling dialogue system
export const useDialogue = (level: number) => {
  const [filteredDialogues, setFilteredDialogues] = useState(
    dialogues.filter(d => d.level === level).sort((a, b) => a.order - b.order)
  );
  const [currentIndex, setCurrentIndex] = useState(0);
  
  // Update filtered dialogues when level changes
  useEffect(() => {
    setFilteredDialogues(
      dialogues.filter(d => d.level === level).sort((a, b) => a.order - b.order)
    );
    setCurrentIndex(0);
  }, [level]);
  
  // Move to next dialogue
  const nextDialogue = useCallback(() => {
    if (currentIndex < filteredDialogues.length - 1) {
      setCurrentIndex(prev => prev + 1);
      return true;
    }
    return false;
  }, [currentIndex, filteredDialogues]);
  
  // Move to previous dialogue
  const prevDialogue = useCallback(() => {
    if (currentIndex > 0) {
      setCurrentIndex(prev => prev - 1);
      return true;
    }
    return false;
  }, [currentIndex]);
  
  // Reset dialogue to beginning
  const resetDialogue = useCallback(() => {
    setCurrentIndex(0);
  }, []);
  
  // Check if there are more dialogues
  const hasMoreDialogues = currentIndex < filteredDialogues.length - 1;
  
  return {
    dialogues: filteredDialogues,
    currentDialogueIndex: currentIndex,
    nextDialogue,
    prevDialogue,
    resetDialogue,
    hasMoreDialogues
  };
};
